from prepro import *
from plate_candidate import *
import matplotlib.pyplot as plt

car_no = int(input('영상번호(0-6): '))
car_no = '%02d' % car_no
image, morph = preprocessing(car_no)
candidates = find_candidates(morph)

fills = [color_candidate_img(image, size)for size, _, _ in candidates]
new_candis = [find_candidates(fill) for fill in fills]
new_candis = [cand[0] for cand in new_candis if cand]
candidate_imgs = [rotate_plate(image, cand) for cand in new_candis]

svm = cv2.ml.SVM_load('SVMtrain.xml')
rows = np.reshape(candidate_imgs, (len(candidate_imgs), -1))
_, results = svm.predict(rows.astype('float32'))
correct = np.where(results == 1)[0]

print("RESULT: \n", results)
print('INDEX: ', correct)

for i, idx in enumerate(correct):
    cv2.imshow('plate image_' + str(i), candidate_imgs[idx])
    cv2.resizeWindow('plate image_' + str(i), (250, 28))

for i, candi in enumerate(new_candis):
    color = (0, 255, 0) if i in correct else (0, 0, 255)
    cv2.polylines(image, [np.int32(cv2.boxPoints(candi))], True, color, 2)

print("SUCCESE") if len(correct) > 0 else print("NOT FOUND")

plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.show()

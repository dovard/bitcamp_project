import cv2
import numpy as np


def color_candidate_img(image, candi_center):
    h, w = image.shape[:2]
    fill = np.zeros((h+2, w+2), np.uint8)
    dif1, dif2 = (25, 25, 25), (25, 25, 25)
    flags = 0xff00 + 4 + cv2.FLOODFILL_FIXED_RANGE
    flags += cv2.FLOODFILL_MASK_ONLY

    pts = np.random.randint(-15, 15, (20, 2))
    pts = pts+candi_center
    for x, y in pts:
        if 0 <= x < w and 0 <= y < h:
            _, _, fill, _ = cv2.floodFill(
                image, fill, (x, y), 255, dif1, dif2, flags)

    return cv2.threshold(fill, 120, 255, cv2.THRESH_BINARY)[1]


def rotate_plate(image, rect):
    center, (w, h), angle = rect
    if w < h:
        w, h = h, w
        angle += 90

    size = image.shape[1::-1]
    print(size)
    rot_mat = cv2.getRotationMatrix2D(center, angle, 1)
    rot_img = cv2.warpAffine(image, rot_mat, size, cv2.INTER_CUBIC)

    crop_img = cv2.getRectSubPix(rot_img, (w, h), center)
    crop_img = cv2.cvtColor(crop_img, cv2.COLOR_BGR2GRAY)
    return cv2.resize(crop_img, (144, 28))

from prepro import *
from plate_candidate import *
import matplotlib.pyplot as plt

car_no = 00
image, morph = preprocessing(car_no)
candidates = find_candidates(morph)

fills = [color_candidate_img(image, size) for size, _, _ in candidates]
new_candis = [find_candidates(fill) for fill in fills]
new_candis = [cand[0] for cand in new_candis if cand]
candidate_imgs = [rotate_plate(image, cand) for cand in new_candis]
# print(new_candis[1])
# print(new_candis)
for i, img in enumerate(candidate_imgs):
    cv2.polylines(image, [np.int32(cv2.boxPoints(
        new_candis[i]))], True, (0, 225, 255), 2)
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.show()


plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.show()
